#define RARVER_MAJOR     6
#define RARVER_MINOR    12
#define RARVER_BETA      0
#define RARVER_DAY       4
#define RARVER_MONTH     5
#define RARVER_YEAR   2022
