/*
 * main.cpp --
 *
 * Copyright (c) 2007-2012 by Joe Mistachkin.  All rights reserved.
 *
 * See the file "license.terms" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * RCS: @(#) $Id: $
 */

#include <cstdlib>
#include <tchar.h>

int _tmain(int argc, TCHAR *argv[])
{
    int result = 0;

    if (argc > 1)
        result = (int)_tcstol(argv[1], NULL, 0L);

    if (result < 0)
        result = -result;

    return result;
}
