#include <codecvt>

int main() {
	std::codecvt_utf8_utf16<wchar_t> codecvt;
	return 0;
}
