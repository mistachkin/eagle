
The "MsgGen.exe" tool is part of the Microsoft Windows Installer XML (WiX)
toolset and as of March 2012 it can be obtained from the following URL:

                             http://wixtoolset.org/

The included project file and assembly attributes in the source code have
been modified to facilitate better integration with the Eagle project and
build system.  No functional changes have been made to the source code.

The resulting assembly has been signed with the strong name key for the Eagle
project and with an Authenticode certificate in accordance with the security
requirements for the Eagle project.
