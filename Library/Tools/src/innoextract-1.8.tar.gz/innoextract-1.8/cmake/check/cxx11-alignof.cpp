int main() {
	return alignof(int) != 1;
}
